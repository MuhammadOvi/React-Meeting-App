<a name="0.1.6"></a>
## 0.1.6 (2017-12-06)



<a name="0.1.3"></a>
## [0.1.3](https://github.com/alexandre-garrec/react-swipe-card/compare/0.1.2...v0.1.3) (2017-02-28)



<a name="0.1.0"></a>
# [0.1.0](https://github.com/alexandre-garrec/react-swipe-card/compare/0.0.8...v0.1.0) (2017-02-20)



<a name="0.0.1"></a>
## 0.0.1 (2017-01-11)



<a name="0.0.1"></a>
## 0.0.1 (2017-01-11)



