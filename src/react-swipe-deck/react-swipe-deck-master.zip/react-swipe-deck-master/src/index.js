import Cards from './Cards'

export Card from './CardSwitcher'

export default Cards
